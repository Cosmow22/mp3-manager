# mp3-manager

A simple cli to manage mp3 songs.

```Powershell
pip install mp3-manager
```
